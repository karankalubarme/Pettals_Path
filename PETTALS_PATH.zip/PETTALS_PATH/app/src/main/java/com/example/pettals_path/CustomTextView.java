package com.example.pettals_path;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.*;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatTextView;

public class CustomTextView extends androidx.appcompat.widget.AppCompatTextView {
    public CustomTextView(Context context) {
        super(context);
    }

    public CustomTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Apply 3D effects here
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setTextSize(getTextSize());
        paint.setColor(getCurrentTextColor());

        // Example: Adding a shadow for a 3D effect
        paint.setShadowLayer(10, 0, 0, Color.GRAY);
        canvas.drawText(getText().toString(), getPaddingLeft(), getBaseline(), paint);
    }
}

