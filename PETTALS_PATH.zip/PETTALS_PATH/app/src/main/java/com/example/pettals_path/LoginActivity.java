package com.example.pettals_path;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginActivity extends AppCompatActivity {

    Button btngetotp,btnverify, btnsignup;
    EditText etphone,etotp;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.Login), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btngetotp = findViewById(R.id.button2);
        btnverify = findViewById(R.id.button3);

        etphone = findViewById(R.id.editTextPhone);
        etotp = findViewById(R.id.editTextNumber);

        btngetotp.setOnClickListener(v -> {
            String number = etphone.getText().toString();
            if (NumberValidation(number)) {
                Toast.makeText(this, "OTP Sent Successfully", Toast.LENGTH_SHORT).show();
                etotp.setEnabled(true);
            }
            else {
                Toast.makeText(this, "Invalid Number", Toast.LENGTH_SHORT).show();
                etotp.setEnabled(false);
            }
        });
    }

    public boolean NumberValidation(String number) {
        String num =number;
        boolean flag;
        if (num.length() == 10) {
            flag = true;
        } else {
            flag = false;
        }
        return flag;
    }

}