package com.example.pettals_path;

import static com.example.pettals_path.R.*;
import static com.example.pettals_path.R.layout.*;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Layout;
import android.view.Gravity;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class DashBoard extends AppCompatActivity {


    Toolbar toolbar001;
    @SuppressLint({"ResourceType", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dash_board);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(id.dash), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        toolbar001=findViewById(id.toolbar2);
        setSupportActionBar(toolbar001);

        toolbar001.setNavigationOnClickListener(v -> {
            DrawerLayout drawerLayout=findViewById(id.drawer_activity);
            drawerLayout.openDrawer(GravityCompat.START);
        });
    }
}