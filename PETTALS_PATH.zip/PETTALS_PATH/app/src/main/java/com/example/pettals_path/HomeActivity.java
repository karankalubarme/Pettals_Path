package com.example.pettals_path;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class HomeActivity extends AppCompatActivity {

    ImageButton ibLogin,ibRegister;
    DrawerLayout drawerLayout;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.Home), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ibLogin=findViewById(R.id.btnLogin);
        ibRegister=findViewById(R.id.btnrgister);

        ibLogin.setOnClickListener(v -> {
            Intent intent=new Intent(HomeActivity.this,LoginActivity.class);
            startActivity(intent);
        });
        ibRegister.setOnClickListener(v -> {
            onShowDialogclick();
        });

        Button btnDashboard=findViewById(R.id.btndash);
        btnDashboard.setOnClickListener(v -> {
            Intent intent=new Intent(HomeActivity.this,DashBoard.class);
            startActivity(intent);
        });
        Button btnManager=findViewById(R.id.manDash);
        btnManager.setOnClickListener(v -> {
            Intent intent=new Intent(HomeActivity.this,ManagerDashboard.class);
            startActivity(intent);
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.admin_menu,menu);
        return true;
    }

    public void onShowDialogclick() {
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog, null);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();
        dialog.setTitle("Select User Type");

        Button btnCust=dialogView.findViewById(R.id.btncust);
        Button btnMan=dialogView.findViewById(R.id.btnMan);
        Button btnDel=dialogView.findViewById(R.id.btnDel);
        btnCust.setOnClickListener(v -> {
            Intent intent=new Intent(HomeActivity.this,CustomerRegister.class);
            startActivity(intent);
        });
        btnMan.setOnClickListener(v ->{
            Toast.makeText(HomeActivity.this, "Manager", Toast.LENGTH_SHORT).show();
            Intent intent2 =new Intent(HomeActivity.this,ManagerRegistration.class);
            startActivity(intent2);
        });
          dialog.show();
    }

}