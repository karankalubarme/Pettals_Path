package com.example.pettals_path;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class CustomerRegister extends AppCompatActivity {

    EditText etName, etMobile, etEmail, etAddress, etDob;
    Button btnRegister, btnLogin;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_customer_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.customerReg), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etName = findViewById(R.id.name);
        etMobile = findViewById(R.id.phone);
        etEmail = findViewById(R.id.email);
        etAddress = findViewById(R.id.address);
        etDob = findViewById(R.id.dob);
        btnRegister = findViewById(R.id.register);

        String name = etName.getText().toString();
        String phone = etMobile.getText().toString();
        String email = etEmail.getText().toString();
        String address = etAddress.getText().toString();
        String dob = etDob.getText().toString();

        etDob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(CustomerRegister.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        etDob.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                    }

                }, year, month, day);
                datePickerDialog.show();
            }
        });

        btnRegister.setOnClickListener(v -> {

            if (DetailsValidator.isEmailValid(etEmail.getText().toString()) && DetailsValidator.isPhoneValid(etMobile.getText().toString())) {

                Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show();
            }
            else if (name.isEmpty()||phone.isEmpty()||email.isEmpty()||address.isEmpty()) {
                Toast.makeText(this, "Wrong Details", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void GoLogin(View view) {
        Intent intent = new Intent(CustomerRegister.this, LoginActivity.class);
        startActivity(intent);
    }
}