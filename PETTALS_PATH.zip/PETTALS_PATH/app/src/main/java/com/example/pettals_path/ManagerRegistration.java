package com.example.pettals_path;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ManagerRegistration extends AppCompatActivity {


    private static final int REQUEST_CODE_UPLOAD = 2;
    private static final int PICK_LIGHT_BILL = 3;
    private static final int PICK_AADHAAR_CARD = 4;
    private static final int PICK_BANK_PASSBOOK = 5;
    private static final int PICK_SHOPKEEPER_PHOTO = 6;
    private Uri lightBillUri, aadhaarCardUri, bankProofUri, photoUri;
    Button UploadLightBill, UploadAadhaar, UploadBankPassbook, register, UploadPhoto;
    ProgressBar ProgressBarLightBill, ProgressBarAadhaarCard, ProgressBarBankPassbook, ProgressBarPhoto;
    EditText businessName, businessAddress, bankName, bankAccountNumber;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_manager_registration);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.managerRegister), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        UploadLightBill = findViewById(R.id.uploadbill);
        UploadAadhaar = findViewById(R.id.uploadaadhar);
        UploadBankPassbook = findViewById(R.id.uploadbankpassbook);
        UploadPhoto = findViewById(R.id.uploadPhoto);
        register = findViewById(R.id.register);


        businessName = findViewById(R.id.shopname);
        businessAddress = findViewById(R.id.shopaddress);
        bankName = findViewById(R.id.bankname);
        bankAccountNumber = findViewById(R.id.bankac);



        register.setOnClickListener(v -> {
            if (validateInput()) {
                Toast.makeText(ManagerRegistration.this, "Registered Successfully!", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(ManagerRegistration.this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
            }
        });

        UploadPhoto.setOnClickListener(v ->{
            //ProgressBarPhoto.setVisibility(View.VISIBLE);
            selectFile(PICK_LIGHT_BILL);
        });


        UploadLightBill.setOnClickListener(v -> {
//ProgressBarLightBill.setVisibility(View.VISIBLE);
            selectFile(PICK_LIGHT_BILL);
        });


        UploadAadhaar.setOnClickListener(v -> {
//ProgressBarAadhaarCard.setVisibility(View.VISIBLE);
            selectFile(PICK_AADHAAR_CARD);
        });


        UploadBankPassbook.setOnClickListener(v -> {
//ProgressBarBankPassbook.setVisibility(View.VISIBLE);
            selectFile(PICK_BANK_PASSBOOK);
        });

    }

    private void selectFile(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/pdf");
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_UPLOAD && resultCode == RESULT_OK && data != null) {
            Uri fileUri = data.getData();
                switch (requestCode) {
                    case PICK_SHOPKEEPER_PHOTO:
                        photoUri = fileUri;
                        //ProgressBarLightBill.setVisibility(View.GONE);
                        break;
                    case PICK_LIGHT_BILL:
                        lightBillUri = fileUri;
                        //ProgressBarLightBill.setVisibility(View.GONE);
                        break;
                    case PICK_AADHAAR_CARD:
                        aadhaarCardUri = fileUri;
                        //ProgressBarAadhaarCard.setVisibility(View.GONE);
                        break;

                    case PICK_BANK_PASSBOOK:
                        bankProofUri = fileUri;
                        //ProgressBarBankPassbook.setVisibility(View.GONE);
                        break;

            }
        }
    }

    private boolean validateInput() {
        if (businessName.getText().toString().isEmpty()) {
            businessName.setError("Please enter Business Name");
            return false;
        }

        if (businessAddress.getText().toString().isEmpty()) {
            businessAddress.setError("Please enter Business Address");
            return false;
        }
        if (bankName.getText().toString().isEmpty()) {
            bankName.setError("Please enter Bank Name");
            return false;
        }
        if (bankAccountNumber.getText().toString().isEmpty()) {
            bankAccountNumber.setError("Please enter Bank Account Number");
            return false;
        }
        if (photoUri == null) {
            Toast.makeText(this, "Please upload Photo", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (lightBillUri == null) {
            Toast.makeText(this, "Please upload Light Bill", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (aadhaarCardUri == null) {
            Toast.makeText(this, "Please upload Aadhaar Card", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (bankProofUri == null) {
            Toast.makeText(this, "Please upload Bank Account Proof", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
