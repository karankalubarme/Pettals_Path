package com.example.pettals_path;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.tabs.TabLayout;

public class ShowItems extends AppCompatActivity {



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_show_items);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.showitem), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        TabLayout tabLayout=findViewById(R.id.tbl);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                int position = tab.getPosition();
                switch (position) {
                    case 0:
                        Fragment addItemFragment=new additemfr();
                        FragmentTransaction ft1=getSupportFragmentManager().beginTransaction();
                        ft1.replace(R.id.frm,addItemFragment);
                        ft1.commit();
                        break;
                    case 1:
                        Fragment updateItemFragment =new UpdateFragment();
                        FragmentTransaction ft2=getSupportFragmentManager().beginTransaction();
                        ft2.replace(R.id.frm, updateItemFragment);
                        ft2.commit();
                        break;
                    case 2:
                        Fragment deleteItemFragment =new DeleteFragment();
                        FragmentTransaction ft3=getSupportFragmentManager().beginTransaction();
                        ft3.replace(R.id.frm, deleteItemFragment);
                        ft3.commit();
                        break;
                    default:
                        Fragment fm5 =new additemfr();
                        FragmentTransaction ft5 =getSupportFragmentManager().beginTransaction();
                        ft5.replace(R.id.frm, fm5);
                        ft5.commit();
                        break;

                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                switch (position) {
                    case 0:
                        Fragment addItemFragment=new additemfr();
                        FragmentTransaction ft1=getSupportFragmentManager().beginTransaction();
                        ft1.replace(R.id.frm,addItemFragment);
                        ft1.commit();
                        break;
                    case 1:
                        Fragment updateItemFragment =new UpdateFragment();
                        FragmentTransaction ft2=getSupportFragmentManager().beginTransaction();
                        ft2.replace(R.id.frm, updateItemFragment);
                        ft2.commit();
                        break;
                    case 2:
                        Fragment deleteItemFragment =new DeleteFragment();
                        FragmentTransaction ft3=getSupportFragmentManager().beginTransaction();
                        ft3.replace(R.id.frm, deleteItemFragment);
                        ft3.commit();
                        break;
                    default:
                        Fragment fm5 =new additemfr();
                        FragmentTransaction ft5 =getSupportFragmentManager().beginTransaction();
                        ft5.replace(R.id.frm, fm5);
                        ft5.commit();
                        break;

                }


            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

                int position = tab.getPosition();
                switch (position) {
                    case 0:
                        Fragment addItemFragment=new additemfr();
                        FragmentTransaction ft1=getSupportFragmentManager().beginTransaction();
                        ft1.replace(R.id.frm,addItemFragment);
                        ft1.commit();
                        break;
                    case 1:
                        Fragment updateItemFragment =new UpdateFragment();
                        FragmentTransaction ft2=getSupportFragmentManager().beginTransaction();
                        ft2.replace(R.id.frm, updateItemFragment);
                        ft2.commit();
                        break;
                    case 2:
                        Fragment deleteItemFragment =new DeleteFragment();
                        FragmentTransaction ft3=getSupportFragmentManager().beginTransaction();
                        ft3.replace(R.id.frm, deleteItemFragment);
                        ft3.commit();
                        break;
                    default:
                        Fragment fm5 =new additemfr();
                        FragmentTransaction ft5 =getSupportFragmentManager().beginTransaction();
                        ft5.replace(R.id.frm, fm5);
                        ft5.commit();
                        break;

                }

            }
        });
    }
}